"""Thoxa programming language interpreter."""

__version__ = "0.1.0"

from .interpreter import Interpreter
from .parser import parse
from .ast_nodes import *

__all__ = ["Interpreter", "parse"]